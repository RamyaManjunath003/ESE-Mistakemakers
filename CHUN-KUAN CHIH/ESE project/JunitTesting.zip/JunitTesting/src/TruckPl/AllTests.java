package TruckPl;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ PedestrianTest.class, VehicleTest.class, GapTest.class })
public class AllTests {

}
